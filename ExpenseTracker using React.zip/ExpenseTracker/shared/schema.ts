import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  amount: doublePrecision("amount").notNull(),
  category: text("category").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  userId: integer("user_id"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Create the insert expense schema with proper validation
export const insertExpenseSchema = createInsertSchema(expenses)
  .pick({
    title: true,
    amount: true,
    category: true,
    date: true,
    userId: true,
  })
  .extend({
    // Allow date to be either a Date object or a string (which we'll convert)
    date: z.union([z.date(), z.string().transform(str => new Date(str))]),
  });

export const expenseFormSchema = insertExpenseSchema.omit({ userId: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

export const CATEGORIES = [
  "groceries",
  "utilities",
  "entertainment",
  "transportation",
  "housing",
  "other",
] as const;

export type Category = typeof CATEGORIES[number];

export const categoryIcons: Record<Category, string> = {
  groceries: "shopping-basket-2-line",
  utilities: "home-wifi-line",
  entertainment: "movie-2-line",
  transportation: "gas-station-line",
  housing: "home-line",
  other: "more-2-line",
};

export const categoryColors: Record<Category, string> = {
  groceries: "blue",
  utilities: "red",
  entertainment: "purple",
  transportation: "amber",
  housing: "green",
  other: "gray",
};
