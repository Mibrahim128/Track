import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ExpenseSummary from "@/components/ExpenseSummary";
import ExpenseForm from "@/components/ExpenseForm";
import ExpenseFilters from "@/components/ExpenseFilters";
import ExpenseList from "@/components/ExpenseList";
import { useState } from "react";
import { Category, Expense } from "@shared/schema";
import { useExpenses } from "@/lib/hooks";

export default function Home() {
  const { data: expenses, isLoading } = useExpenses();
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");

  // Calculate filtered expenses
  const filteredExpenses = expenses?.filter((expense: Expense) => {
    // Search term filter
    if (searchTerm && !expense.title.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }

    // Category filter
    if (categoryFilter && categoryFilter !== "all" && expense.category !== categoryFilter) {
      return false;
    }

    // Date filter
    if (dateFilter && dateFilter !== "all") {
      const expenseDate = new Date(expense.date);
      const currentDate = new Date();
      
      switch (dateFilter) {
        case 'current-month':
          return expenseDate.getMonth() === currentDate.getMonth() && 
                 expenseDate.getFullYear() === currentDate.getFullYear();
        case 'last-month':
          const lastMonth = currentDate.getMonth() === 0 ? 11 : currentDate.getMonth() - 1;
          const lastMonthYear = currentDate.getMonth() === 0 ? currentDate.getFullYear() - 1 : currentDate.getFullYear();
          return expenseDate.getMonth() === lastMonth && expenseDate.getFullYear() === lastMonthYear;
        case 'last-3-months':
          const threeMonthsAgo = new Date();
          threeMonthsAgo.setMonth(currentDate.getMonth() - 3);
          return expenseDate >= threeMonthsAgo;
        case 'current-year':
          return expenseDate.getFullYear() === currentDate.getFullYear();
        default:
          return true;
      }
    }

    return true;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="lg:grid lg:grid-cols-3 lg:gap-8">
            {/* Left Column (Summary + Add Expense Form) */}
            <div className="lg:col-span-1 space-y-6">
              <ExpenseSummary expenses={expenses || []} isLoading={isLoading} />
              <ExpenseForm />
            </div>

            {/* Right Column (Expense List) */}
            <div className="mt-6 lg:mt-0 lg:col-span-2">
              <ExpenseFilters 
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                categoryFilter={categoryFilter}
                setCategoryFilter={setCategoryFilter}
                dateFilter={dateFilter}
                setDateFilter={setDateFilter}
              />
              
              <ExpenseList 
                expenses={filteredExpenses || []} 
                isLoading={isLoading}
              />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
