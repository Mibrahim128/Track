// Format a date to a human-readable string
export function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-US', {
    month: 'short', 
    day: 'numeric', 
    year: 'numeric'
  });
}

// Format a number to a currency string
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

// Get the current date as YYYY-MM-DD
export function getCurrentDate(): string {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Get the first day of the current month
export function getFirstDayOfMonth(): Date {
  const today = new Date();
  return new Date(today.getFullYear(), today.getMonth(), 1);
}

// Get the first day of the previous month
export function getFirstDayOfPreviousMonth(): Date {
  const today = new Date();
  return new Date(today.getFullYear(), today.getMonth() - 1, 1);
}

// Get the date that was 3 months ago
export function getThreeMonthsAgo(): Date {
  const today = new Date();
  return new Date(today.getFullYear(), today.getMonth() - 3, today.getDate());
}

// Get the first day of the current year
export function getFirstDayOfYear(): Date {
  const today = new Date();
  return new Date(today.getFullYear(), 0, 1);
}
