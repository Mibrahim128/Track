import { useQuery, useMutation } from "@tanstack/react-query";
import { Expense } from "@shared/schema";
import { apiRequest } from "./queryClient";
import { queryClient } from "./queryClient";

// Hook to fetch all expenses
export function useExpenses() {
  return useQuery<Expense[]>({
    queryKey: ['/api/expenses'],
  });
}

// Hook to delete an expense
export function useDeleteExpense() {
  return useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/expenses/${id}`, undefined);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
    },
  });
}

// Hook to create an expense
export function useCreateExpense() {
  return useMutation({
    mutationFn: async (expense: Omit<Expense, 'id'>) => {
      const response = await apiRequest("POST", "/api/expenses", expense);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
    },
  });
}
