import { Expense, categoryColors, categoryIcons } from "@shared/schema";
import { formatCurrency, formatDate } from "@/lib/utils/date";
import { Trash2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface ExpenseItemProps {
  expense: Expense;
}

export default function ExpenseItem({ expense }: ExpenseItemProps) {
  const { toast } = useToast();
  const { id, title, amount, category, date } = expense;
  
  // Get the appropriate icon based on category
  const icon = categoryIcons[category as keyof typeof categoryIcons] || "more-2-line";
  
  // Get the appropriate color based on category
  const color = categoryColors[category as keyof typeof categoryColors] || "gray";
  
  const deleteExpenseMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", `/api/expenses/${id}`, undefined);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch expenses query
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      
      toast({
        title: "Expense Deleted",
        description: "Your expense has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete expense: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="p-5 hover:bg-gray-50">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
        <div className="flex items-start">
          <div className={`bg-${color}-100 p-2 rounded-md mr-4 text-${color}-600`}>
            <i className={`ri-${icon} text-lg`}></i>
          </div>
          <div>
            <h3 className="text-base font-medium">{title}</h3>
            <div className="flex items-center space-x-2 mt-1">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-${color}-100 text-${color}-800`}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </span>
              <span className="text-sm text-gray-500">{formatDate(date)}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center ml-auto">
          <span className="text-lg font-semibold mr-4">{formatCurrency(amount)}</span>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button 
                className="text-gray-400 hover:text-red-500" 
                title="Delete expense"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete the expense "{title}" of {formatCurrency(amount)}.
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={() => deleteExpenseMutation.mutate()}
                  className="bg-red-500 hover:bg-red-600"
                >
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  );
}
