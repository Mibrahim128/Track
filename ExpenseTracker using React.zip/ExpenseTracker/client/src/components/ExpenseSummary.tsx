import { Card, CardContent } from "@/components/ui/card";
import { Expense } from "@shared/schema";
import { formatCurrency } from "@/lib/utils/date";
import { Skeleton } from "@/components/ui/skeleton";

interface ExpenseSummaryProps {
  expenses: Expense[];
  isLoading: boolean;
}

export default function ExpenseSummary({ expenses, isLoading }: ExpenseSummaryProps) {
  // Calculate total expenses
  const totalExpense = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  // Calculate monthly expenses
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  
  const monthlyExpense = expenses
    .filter(expense => {
      const expenseDate = new Date(expense.date);
      return expenseDate.getMonth() === currentMonth && 
             expenseDate.getFullYear() === currentYear;
    })
    .reduce((sum, expense) => sum + expense.amount, 0);
  
  // Get unique categories
  const uniqueCategories = new Set(expenses.map(expense => expense.category));
  
  // Get last added expense
  const lastExpense = expenses.length > 0 ? expenses[0] : null;
  const lastExpenseDate = lastExpense ? new Date(lastExpense.date) : null;
  
  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-5 space-y-4">
          <div className="border-b border-gray-200 pb-4">
            <Skeleton className="h-6 w-40 mb-2" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-8 w-32" />
            </div>
            <div>
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-8 w-32" />
            </div>
            <div>
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-8 w-8" />
            </div>
            <div>
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="p-5 border-b border-gray-200">
          <h2 className="text-lg font-medium">Expense Summary</h2>
        </div>
        
        <div className="p-5 grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Total Expenses</p>
            <p className="text-2xl font-semibold">{formatCurrency(totalExpense)}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">This Month</p>
            <p className="text-2xl font-semibold">{formatCurrency(monthlyExpense)}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Categories</p>
            <p className="text-xl font-semibold">{uniqueCategories.size}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Last Added</p>
            <p className="text-sm font-medium">
              {lastExpenseDate 
                ? lastExpenseDate.toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric', 
                    year: 'numeric' 
                  })
                : 'No expenses yet'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
