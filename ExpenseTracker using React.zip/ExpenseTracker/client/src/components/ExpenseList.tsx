import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Expense } from "@shared/schema";
import ExpenseItem from "./ExpenseItem";
import EmptyState from "./EmptyState";
import { Skeleton } from "@/components/ui/skeleton";

interface ExpenseListProps {
  expenses: Expense[];
  isLoading: boolean;
}

export default function ExpenseList({ expenses, isLoading }: ExpenseListProps) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-0">
          <div className="p-5 border-b border-gray-200 flex justify-between items-center">
            <Skeleton className="h-6 w-40" />
            <Skeleton className="h-4 w-32" />
          </div>
          
          <div className="divide-y divide-gray-200">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="p-5">
                <div className="flex justify-between items-start">
                  <div className="flex items-start">
                    <Skeleton className="h-10 w-10 rounded-md mr-4" />
                    <div>
                      <Skeleton className="h-5 w-32 mb-2" />
                      <div className="flex items-center space-x-2">
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-4 w-24" />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Skeleton className="h-6 w-24 mr-4" />
                    <Skeleton className="h-8 w-8 rounded-full" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="p-5 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium">Your Expenses</h2>
          <span className="text-sm text-gray-500">
            Showing {expenses.length} {expenses.length === 1 ? 'expense' : 'expenses'}
          </span>
        </div>

        {expenses.length > 0 ? (
          <div className="divide-y divide-gray-200">
            {expenses.map((expense) => (
              <ExpenseItem key={expense.id} expense={expense} />
            ))}
          </div>
        ) : (
          <EmptyState />
        )}

        {expenses.length > 0 && (
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 sm:px-6">
            <div className="flex items-center justify-between">
              <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm text-gray-700">
                    Showing <span className="font-medium">1</span> to{" "}
                    <span className="font-medium">{expenses.length}</span> of{" "}
                    <span className="font-medium">{expenses.length}</span> expenses
                  </p>
                </div>
                <div>
                  <nav className="flex items-center" aria-label="Pagination">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mr-2"
                      disabled
                    >
                      Previous
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      disabled
                    >
                      Next
                    </Button>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
