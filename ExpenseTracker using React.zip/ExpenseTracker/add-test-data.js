// Script to add test data to our expense tracker
const expenses = [
  {
    title: "Weekly Grocery Shopping",
    amount: 87.45,
    category: "groceries",
    date: "2025-04-22"
  },
  {
    title: "Electricity Bill",
    amount: 124.30,
    category: "utilities",
    date: "2025-04-15"
  },
  {
    title: "Movie Tickets",
    amount: 28.50,
    category: "entertainment",
    date: "2025-04-26"
  },
  {
    title: "Gas Fill-up",
    amount: 45.80,
    category: "transportation",
    date: "2025-04-20"
  },
  {
    title: "Rent Payment",
    amount: 1250.00,
    category: "housing",
    date: "2025-04-01"
  },
  {
    title: "Internet Bill",
    amount: 65.99,
    category: "utilities",
    date: "2025-04-16"
  },
  {
    title: "Birthday Gift for Friend",
    amount: 35.99,
    category: "other",
    date: "2025-04-18"
  },
  {
    title: "Lunch with Colleagues",
    amount: 42.75,
    category: "entertainment",
    date: "2025-04-14"
  },
  {
    title: "Monthly Bus Pass",
    amount: 78.00,
    category: "transportation",
    date: "2025-04-03"
  },
  {
    title: "Pharmacy Items",
    amount: 23.45,
    category: "other",
    date: "2025-04-24"
  }
];

// Function to add each expense
async function addExpense(expense) {
  try {
    const response = await fetch('http://localhost:5000/api/expenses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(expense),
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      console.error(`Failed to add expense: ${expense.title}`, errorData);
      return false;
    }
    
    const data = await response.json();
    console.log(`Added expense: ${expense.title}`);
    return true;
  } catch (error) {
    console.error(`Error adding expense: ${expense.title}`, error);
    return false;
  }
}

// Add all expenses
async function addAllExpenses() {
  console.log("Starting to add test data...");
  
  for (const expense of expenses) {
    await addExpense(expense);
  }
  
  console.log("Finished adding test data!");
}

// Run the function
addAllExpenses();